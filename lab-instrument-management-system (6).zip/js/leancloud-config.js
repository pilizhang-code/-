/**
 * LeanCloud配置文件
 * 请在此处填写您的LeanCloud应用配置
 */

// LeanCloud配置
const LC_CONFIG = {
    appId: 'i3HOlSULshlcZHb2eLPPeAeq-gzGzoHsz',
    appKey: 'RIRWzdOmEoM02P4gbAEXQp69',
    serverURLs: 'https://i3holsul.lc-cn-n1-shared.com' // 国内节点需要配置
};
